function splitPayload(url = "") {
  const index = url.search(/[?#]/);
  return index < 0 ? [url, ""] : [url.slice(0, index), url.slice(index)];
}

function xorKeyValue(key) {
  const value = /^\d+$/.test(key) ? Number(key) : parseInt(key, 36);
  return Number.isFinite(value) && value > 1 ? (value % 30) + 2 : 2;
}

const encoder = {
  // biome-ignore format: compact
  xor: { encode: (url, key) => url && encodeURIComponent(url.split("").map((char, index) => (index % xorKeyValue(key) ? String.fromCharCode(char.charCodeAt(0) ^ xorKeyValue(key)) : char)).join("")), decode: (url, key) => { const [value, tail] = splitPayload(url); if (!value) return value; const xorKey = xorKeyValue(key); return decodeURIComponent(value).split("").map((char, index) => (index % xorKey ? String.fromCharCode(char.charCodeAt(0) ^ xorKey) : char)).join("") + tail } },
};

window.encode = {
  xor: encoder.xor.encode,
};

window.decode = {
  xor: encoder.xor.decode,
};

let swReady = false;
let swReadyResolve;
const swReadyPromise = new Promise(resolve => {
  swReadyResolve = resolve;
});

function isTabsPage() {
  return document.body?.id === "no" || Boolean(document.getElementById("frame-container"));
}

window.addEventListener("load", async () => {
  if (isTabsPage()) {
    swReady = true;
    swReadyResolve();
    return;
  }

  if (!("serviceWorker" in navigator)) {
    swReady = true;
    swReadyResolve();
    return;
  }

  try {
    const registration = await navigator.serviceWorker.register("../sw.js", {
      scope: "/uv/",
    });

    if (registration.active) {
      swReady = true;
      swReadyResolve();
      return;
    }

    const worker = registration.installing || registration.waiting;
    if (worker) {
      worker.addEventListener("statechange", function onStateChange() {
        if (this.state === "activated") {
          swReady = true;
          swReadyResolve();
          worker.removeEventListener("statechange", onStateChange);
        }
      });
    } else {
      swReady = true;
      swReadyResolve();
    }
  } catch (err) {
    console.error("[SW] registration failed:", err);
    swReady = true;
    swReadyResolve();
  }
});

async function waitForServiceWorker() {
  if (swReady) return;
  await Promise.race([swReadyPromise, new Promise(resolve => setTimeout(resolve, 4000))]);
}

const form = document.getElementById("search-form");
const input = document.getElementById("input");

if (form && input && !isTabsPage()) {
  form.addEventListener("submit", async event => {
    event.preventDefault();
    if (askOwningTabs(input.value)) return;
    try {
      if (isInTabMode) await navigate(input.value, "");
      else await navigate(input.value, "/tabs");
    } catch {
      await navigate(input.value, "/tabs");
    }
  });
}

function isScramjet(proxyOverride) {
  const choice = proxyOverride ?? store.get("proxy");
  return choice === "sj";
}

async function encodeUrl(url, proxyOverride) {
  if (isScramjet(proxyOverride)) {
    if (window.__ready) {
      await window.__ready;
    }
    if (window.__urls?.encodeUrl) {
      return window.__urls.encodeUrl(url);
    }
  }

  return `/uv/${__uv$config.encodeUrl ? __uv$config.encodeUrl(url) : window.encode.xor(url)}`;
}

function customWispUrl() {
  const custom = store.get("wisp-url")?.trim();
  return custom && /^wss?:\/\//i.test(custom) ? custom : null;
}

const SERVER_FILTER = true;

async function checkBlocked(url) {
  if (!SERVER_FILTER || customWispUrl()) return null;
  let host;
  try {
    const parsed = new URL(url, window.location.origin);
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return null;
    host = parsed.hostname;
  } catch {
    return null;
  }
  try {
    const response = await fetch("/filter/verdict", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ host }),
    });
    if (!response.ok) return null;
    const verdict = await response.json();
    return verdict.blocked ? verdict : null;
  } catch {
    return null;
  }
}

function blockPageUrl(url, verdict) {
  return `/block.html#${encodeURIComponent(`${verdict.source}|${url}`)}`;
}

window.blockPages = { check: checkBlocked, pageUrl: blockPageUrl };

async function navigate(value, path, proxyOverride) {
  await waitForServiceWorker();
  if (window.__settled) await window.__settled();

  let url = value.trim();
  const engine = store.get("engine");
  const defaultEngine = location.hostname.endsWith(".workers.dev") ? "https://www.google.com/search?q=" : "https://search.brave.com/search?q=";
  const searchUrl = engine ? engine : defaultEngine;

  if (!isValidUrl(url)) {
    url = searchUrl + url;
  } else if (!(url.startsWith("https://") || url.startsWith("http://"))) {
    url = `https://${url}`;
  }

  const verdict = await checkBlocked(url);
  if (verdict) {
    const blockedPage = blockPageUrl(url, verdict);
    if (path) {
      sessionStorage.setItem("GoUrl", blockedPage);
      location.href = path;
    } else {
      location.href = blockedPage;
    }
    return;
  }

  const proxyChoice = proxyOverride ?? store.get("proxy");
  const proxyUrl = await encodeUrl(url, proxyChoice);
  sessionStorage.setItem("GoUrl", proxyUrl);

  if (path || !owningTabsWindow()) {
    location.href = path || "/tabs";
  } else {
    window.location.href = proxyUrl;
  }
}

function openUrl(value, proxyOverride) {
  navigate(value, "/tabs", proxyOverride);
}

// Open link in about:blank
function blank(value, proxyOverride) {
  navigate(value, "", proxyOverride);
}

function isValidUrl(val = "") {
  return /^http(s?):\/\//.test(val) || (val.includes(".") && val[0] !== " ");
}

(() => {
  // Full paths only, never concatenated: the build rewrites whole literals.
  const vendor = self.__deps || {};

  const BUILT_WISP = null;

  function unpackWisp(pieces, keyText) {
    const parts = [...pieces]
      .sort((a, b) => a[0] - b[0])
      .map(([, text]) => {
        let base64 = "";
        for (let i = 0; i < text.length; i++) base64 += String.fromCharCode(text.charCodeAt(i) ^ keyText.charCodeAt(i % keyText.length));
        return Uint8Array.from(atob(base64), char => char.charCodeAt(0));
      });
    const bytes = new Uint8Array(parts.reduce((total, part) => total + part.length, 0));
    let at = 0;
    for (const part of parts) {
      bytes.set(part, at);
      at += part.length;
    }
    return new TextDecoder().decode(bytes);
  }

  const wispReachable = url =>
    new Promise(resolve => {
      let socket;
      let settled = false;
      let stableTimer;
      const done = ok => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        clearTimeout(stableTimer);
        try {
          socket?.close();
        } catch {}
        resolve(ok);
      };
      const timer = setTimeout(() => done(false), 5000);
      try {
        socket = new WebSocket(url);
        socket.binaryType = "arraybuffer";
        socket.onmessage = () => {
          if (!stableTimer) stableTimer = setTimeout(() => done(true), 1000);
        };
        socket.onerror = () => done(false);
        socket.onclose = () => done(false);
      } catch {
        done(false);
      }
    });

  function builtWispCandidates(excluded = []) {
    const all = [BUILT_WISP.p, BUILT_WISP.f].flatMap(list => list.map(pieces => unpackWisp(pieces, BUILT_WISP.k)));
    return all.filter(url => !excluded.includes(url));
  }

  async function pickBuiltWisp(excluded = []) {
    const candidates = builtWispCandidates(excluded);
    if (candidates.length === 0) return builtWispCandidates()[0];
    if (candidates.length === 1) return candidates[0];
    let ordered = candidates;
    const remembered = store.get("wisp-choice");
    if (remembered && candidates.length > 1) {
      const hashes = await Promise.all(candidates.map(hashSignature));
      const index = hashes.indexOf(remembered);
      if (index > 0) ordered = [candidates[index], ...candidates.slice(0, index), ...candidates.slice(index + 1)];
    }
    for (const url of ordered) {
      if (await wispReachable(url)) {
        store.set("wisp-choice", await hashSignature(url));
        return url;
      }
    }
    return ordered[0];
  }

  async function getWispUrl() {
    const custom = customWispUrl();
    if (custom) return custom;
    if (BUILT_WISP) return pickBuiltWisp();
    const protocol = location.protocol === "https:" ? "wss" : "ws";
    return `${protocol}://${location.host}/wisp/`;
  }

  function blockAwareEpoxy(transportPath) {
    return `
      const { default: EpoxyTransport } = await import(${JSON.stringify(transportPath)});
      class BlockAwareEpoxy extends EpoxyTransport {
        async request(...args) {
          try {
            return await super.request(...args);
          } catch (error) {
            const message = String(error?.message ?? error);
            const kind = message.includes("WispCloseReason(ServerStreamBlockedAddress") ? "blocked"
              : message.includes("WispCloseReason(ServerStreamUnreachable") ? "not-found" : null;
            if (!kind) throw error;
            return { status: 451, statusText: "Unavailable For Legal Reasons", headers: { "x-interstellar-block": kind }, body: null };
          }
        }
      }
      return [BlockAwareEpoxy, ${JSON.stringify(transportPath)}];
    `;
  }

  async function hashSignature(text) {
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
    return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
  }

  async function ensureTransport(connection, transportPath, options, rawSignature, manualCode) {
    const signature = await hashSignature(rawSignature);
    let current = "";
    try {
      current = await connection.getTransport();
    } catch {}

    if (current === transportPath && store.get("transport-signature") === signature) return;

    if (manualCode) await connection.setManualTransport(manualCode, options);
    else await connection.setTransport(transportPath, options);
    store.set("transport-signature", signature);
  }

  let activeConnection = null;
  let activeWisp = null;
  let lastFailover = 0;
  let failoverRunning = false;

  async function applyWispTransport(connection, wisp) {
    if (store.get("transport") === "libcurl") {
      await ensureTransport(connection, vendor.libcurl, [{ websocket: wisp }], `${vendor.libcurl}|${wisp}`);
    } else if (customWispUrl()) {
      await ensureTransport(connection, vendor.epoxy, [{ wisp }], `${vendor.epoxy}|${wisp}`);
    } else {
      await ensureTransport(connection, vendor.epoxy, [{ wisp }], `${vendor.epoxy}|${wisp}|block-aware`, blockAwareEpoxy(vendor.epoxy));
    }
  }

  async function failOverWisp() {
    if (!activeConnection || !BUILT_WISP || customWispUrl() || failoverRunning) return;
    if (Date.now() - lastFailover < 5000) return;
    failoverRunning = true;
    try {
      const failed = activeWisp;
      const next = await pickBuiltWisp([failed]);
      if (next === failed) return;
      activeWisp = next;
      lastFailover = Date.now();
      await applyWispTransport(activeConnection, next);
    } catch {
    } finally {
      failoverRunning = false;
    }
  }

  async function init() {
    const [{ BareMuxConnection }, { ScramjetController }] = await Promise.all([import(vendor.baremux), window.$scramjetLoadController()]);

    const scramjet = new ScramjetController(self.__scramjet$config);
    await scramjet.init();

    const connection = new BareMuxConnection(vendor.baremuxWorker);
    activeConnection = connection;
    activeWisp = await getWispUrl();
    await applyWispTransport(connection, activeWisp);

    navigator.serviceWorker?.addEventListener("message", event => {
      if (event.data?.type === "wisp-failed") failOverWisp();
    });

    window.__urls = {
      encodeUrl: url => scramjet.encodeUrl(url),
      decodeUrl: url => scramjet.decodeUrl(url),
    };
  }

  async function boot() {
    if (typeof window.$scramjetLoadController !== "function" || !self.__scramjet$config) return;
    try {
      await init();
    } catch (error) {
      console.error("Scramjet transport failed to start:", error);
    }
  }

  const domReady = document.readyState === "loading" ? new Promise(resolve => document.addEventListener("DOMContentLoaded", resolve, { once: true })) : Promise.resolve();

  window.__ready = domReady.then(boot);
})();

window.__settled = async (timeout = 8000) => {
  if (!window.__ready) return;
  await Promise.race([window.__ready.catch(() => {}), new Promise(resolve => setTimeout(resolve, timeout))]);
};

function owningTabsWindow() {
  try {
    const tabs = window.parent?.document?.getElementById("frame-container");
    return window.frameElement && tabs && window.frameElement.parentElement === tabs ? window.parent : null;
  } catch {
    return null;
  }
}

function askOwningTabs(value) {
  const tabs = owningTabsWindow();
  if (!tabs) return false;
  tabs.postMessage({ type: "interstellar:tabs-navigate", value }, location.origin);
  return true;
}
